export function HeadIngs() {
  return (
    <>
      <h1 className="font-black text-4xl pb-4">label lab</h1>
      <h2 className="font-bold	pb-2">Sign up for an account</h2>
      {/* <h3 className='font-[300]'>Welcome back! please enter your detail</h3> */}
    </>
  );
}
