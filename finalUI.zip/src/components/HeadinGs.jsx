export function HeadIngs() {
  return (
    <>
      <h1 className="font-black text-[48px]">label lab</h1>
      <h2 className="lowfonts font-[700]">Login in to your account</h2>
      <h3 className="lowfonts font-[300] text-[14px] pt-[0.4rem]">
        Welcome back! please enter your detail
      </h3>
    </>
  );
}
